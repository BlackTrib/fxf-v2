(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/components_0y3mwaw._.js","static/chunks/0t6e_lucide-react_dist_esm_icons_0sg.m57._.js"],
    source: "dynamic"
});
