module.exports = [
"[project]/.next-internal/server/app/servere/dedicat/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_servere_dedicat_page_actions_0sqvfbj.js.map