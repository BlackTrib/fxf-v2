module.exports = [
"[project]/.next-internal/server/app/gazduire/wordpress/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gazduire_wordpress_page_actions_01y3z4j.js.map