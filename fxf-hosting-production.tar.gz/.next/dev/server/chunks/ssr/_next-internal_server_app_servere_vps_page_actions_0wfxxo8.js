module.exports = [
"[project]/.next-internal/server/app/servere/vps/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_servere_vps_page_actions_0wfxxo8.js.map