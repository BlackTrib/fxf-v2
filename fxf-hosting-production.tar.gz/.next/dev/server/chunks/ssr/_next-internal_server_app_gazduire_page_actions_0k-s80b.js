module.exports = [
"[project]/.next-internal/server/app/gazduire/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gazduire_page_actions_0k-s80b.js.map