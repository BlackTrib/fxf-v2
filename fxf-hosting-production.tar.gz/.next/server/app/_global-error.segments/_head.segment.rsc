1:"$Sreact.fragment"
2:I[46608,["/_next/static/chunks/166m2o~n.xz3f.js","/_next/static/chunks/0r55phvf3mn69.js"],"ViewportBoundary"]
3:I[46608,["/_next/static/chunks/166m2o~n.xz3f.js","/_next/static/chunks/0r55phvf3mn69.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"F5x52MurIn_F3zp_8oHSZ"}
