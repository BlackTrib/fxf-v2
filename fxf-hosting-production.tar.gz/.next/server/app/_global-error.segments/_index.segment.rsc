1:"$Sreact.fragment"
2:I[90861,["/_next/static/chunks/166m2o~n.xz3f.js","/_next/static/chunks/0r55phvf3mn69.js"],"default"]
3:I[57834,["/_next/static/chunks/166m2o~n.xz3f.js","/_next/static/chunks/0r55phvf3mn69.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"F5x52MurIn_F3zp_8oHSZ"}
