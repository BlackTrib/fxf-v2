1:"$Sreact.fragment"
2:I[90861,["/_next/static/chunks/0xztoo~7fam0q.js","/_next/static/chunks/0r55phvf3mn69.js","/_next/static/chunks/0l2evoyije85f.js"],"default"]
3:I[57834,["/_next/static/chunks/0xztoo~7fam0q.js","/_next/static/chunks/0r55phvf3mn69.js","/_next/static/chunks/0l2evoyije85f.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"F5x52MurIn_F3zp_8oHSZ"}
