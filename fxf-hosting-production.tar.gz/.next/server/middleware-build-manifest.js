globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/F5x52MurIn_F3zp_8oHSZ/_buildManifest.js",
    "static/F5x52MurIn_F3zp_8oHSZ/_ssgManifest.js",
    "static/F5x52MurIn_F3zp_8oHSZ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0nc-~j4u8fa4-.js",
    "static/chunks/07t.fsv3wtdie.js",
    "static/chunks/01v4ji714~oz7.js",
    "static/chunks/13o-gf8msbns..js",
    "static/chunks/turbopack-0n5eq7bc0b64b.js"
  ]
};
