(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__07jtrfx._.css","static/chunks/node_modules__pnpm_0l622zd._.js","static/chunks/_0jvuhw5._.js"],
    source: "dynamic"
});
