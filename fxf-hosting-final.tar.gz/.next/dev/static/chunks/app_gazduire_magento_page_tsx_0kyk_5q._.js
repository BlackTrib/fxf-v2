(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/components_10ue08a._.js","static/chunks/0t6e_lucide-react_dist_esm_icons_08hf.a3._.js"],
    source: "dynamic"
});
