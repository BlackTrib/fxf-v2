module.exports = [
"[project]/.next-internal/server/app/gazduire/performance/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gazduire_performance_page_actions_0735245.js.map