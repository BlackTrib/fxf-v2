module.exports = [
"[project]/.next-internal/server/app/gazduire/web/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gazduire_web_page_actions_06jjnnt.js.map