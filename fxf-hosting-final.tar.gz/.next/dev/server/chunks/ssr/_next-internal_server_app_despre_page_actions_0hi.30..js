module.exports = [
"[project]/.next-internal/server/app/despre/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_despre_page_actions_0hi.30..js.map