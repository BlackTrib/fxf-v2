var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0wn_e13._.js")
R.c("server/chunks/[root-of-the-server]__04xk2ls._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(45815)
module.exports=R.m(45815).exports
