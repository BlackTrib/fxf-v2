:HL["/_next/static/chunks/0br9.x.imb1.3.css","style"]
:HL["/_next/static/chunks/0u6s44mssaffh.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.0q-301v4kxxnr.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.0eehd8tgys7nv.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/og-image.jpg","image",{"type":"image/jpeg"}]
:HL["/logo.png","image",{"type":"image/png"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"dIVM5vPv4R-6sWK3CHv62"}
