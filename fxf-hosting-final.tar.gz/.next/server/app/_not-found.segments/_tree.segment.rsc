:HL["/_next/static/chunks/0br9.x.imb1.3.css","style"]
:HL["/_next/static/chunks/0u6s44mssaffh.css","style"]
:HL["/og-image.jpg","image",{"type":"image/jpeg"}]
:HL["/logo.png","image",{"type":"image/png"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"dIVM5vPv4R-6sWK3CHv62"}
