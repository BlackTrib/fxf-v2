var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0z8dy0v._.js")
R.c("server/chunks/[root-of-the-server]__04xk2ls._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_0o-41u5.js")
R.m(21749)
module.exports=R.m(21749).exports
