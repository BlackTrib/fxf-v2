module.exports=[85546,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_servere_vps_page_actions_0wfxxo8.js.map