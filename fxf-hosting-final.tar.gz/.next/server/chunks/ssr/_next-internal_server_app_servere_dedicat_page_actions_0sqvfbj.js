module.exports=[63020,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_servere_dedicat_page_actions_0sqvfbj.js.map