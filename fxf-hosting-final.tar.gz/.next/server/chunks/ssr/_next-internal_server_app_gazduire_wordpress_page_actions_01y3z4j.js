module.exports=[94220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gazduire_wordpress_page_actions_01y3z4j.js.map