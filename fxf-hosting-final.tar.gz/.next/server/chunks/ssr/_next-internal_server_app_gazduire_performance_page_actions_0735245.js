module.exports=[27609,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gazduire_performance_page_actions_0735245.js.map