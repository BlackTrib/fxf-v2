module.exports=[58368,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_servere_storage_page_actions_0d9ptaz.js.map