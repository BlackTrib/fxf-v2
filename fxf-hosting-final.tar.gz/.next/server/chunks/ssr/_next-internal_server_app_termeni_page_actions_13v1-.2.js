module.exports=[63152,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_termeni_page_actions_13v1-.2.js.map