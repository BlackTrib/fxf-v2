module.exports=[77266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gazduire_opencart_page_actions_0p1_eyh.js.map