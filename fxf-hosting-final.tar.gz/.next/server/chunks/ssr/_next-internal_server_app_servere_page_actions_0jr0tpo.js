module.exports=[15019,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_servere_page_actions_0jr0tpo.js.map