module.exports=[64350,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_despre_page_actions_0hi.30..js.map