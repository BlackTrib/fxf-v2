import type { Metadata } from 'next'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { 
  Search, ArrowRight, Check, TrendingUp, Target, FileText, 
  Link2, Globe, BarChart2, Gauge, Map, Users,
  Eye, Layers, Zap, LineChart, Award, Clock
} from 'lucide-react'
import { PageHeroVisual } from '@/components/page-hero-visual'

export const metadata: Metadata = {
  title: 'SEO București | Optimizare Google | Agenție SEO | FXF',
  description: 'Servicii SEO profesionale în București. Creștem vizibilitatea pe Google prin audit tehnic, conținut și link building. Rezultate măsurabile, rapoarte lunare.',
  keywords: [
    'optimizare seo',
    'servicii seo romania',
    'seo romania',
    'optimizare google',
    'agentie seo',
    'seo profesional',
    'optimizare site google',
    'servicii seo',
    'pozitionare google',
    'seo local',
    'audit seo',
    'consultant seo romania',
    'pret seo',
    'seo bucuresti',
  ],
  openGraph: {
    title: 'SEO București | Optimizare Google | FXF Web Solution',
    description: 'Creștem vizibilitatea afacerii tale pe Google din București. Audit SEO, optimizare on-page, conținut și link building cu rezultate măsurabile.',
    url: 'https://fxf.ro/servicii/optimizare-seo',
  },
  alternates: {
    canonical: 'https://fxf.ro/servicii/optimizare-seo',
  },
}

const serviceSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Optimizare SEO București',
  description: 'Servicii SEO profesionale în București. Audit tehnic, optimizare on-page, link building și creșterea vizibilității organice pe Google.',
  provider: {
    '@type': 'Organization',
    name: 'FXF Web Solution',
    url: 'https://fxf.ro',
  },
  areaServed: { '@type': 'City', name: 'București' },
  url: 'https://fxf.ro/servicii/optimizare-seo',
  serviceType: 'SEO',
}

const services = [
  {
    icon: Search,
    title: 'Audit SEO Tehnic',
    desc: 'Analiză completă a site-ului: indexare, crawlability, structură URL-uri, viteze de încărcare, erori 404, redirectări, duplicate content și toate aspectele tehnice.',
  },
  {
    icon: FileText,
    title: 'Optimizare On-Page',
    desc: 'Optimizare titluri, meta descrieri, heading-uri, imagini, structură internă de linkuri, schema markup și conținut pentru cuvintele cheie relevante.',
  },
  {
    icon: Layers,
    title: 'Cercetare Cuvinte Cheie',
    desc: 'Identificăm cuvintele cheie cu potențial maxim pentru afacerea ta: volum de căutare, dificultate, intent și oportunități de long-tail.',
  },
  {
    icon: Link2,
    title: 'Link Building Etic',
    desc: 'Construim un profil de backlink-uri natural și autoritar prin guest posting, mențiuni în presă, directoare de nișă și parteneriate relevante.',
  },
  {
    icon: Map,
    title: 'SEO Local',
    desc: 'Optimizare pentru căutări locale: Google Business Profile, citat-uri NAP consistente, recenzii și prezență în directoare locale.',
  },
  {
    icon: LineChart,
    title: 'Raportare & Analiză',
    desc: 'Rapoarte lunare detaliate cu poziții, trafic organic, conversii și recomandări. Transparență totală asupra rezultatelor.',
  },
]

const benefits = [
  { icon: Eye, title: 'Vizibilitate organică', desc: 'Apari în fața clienților când caută activ ce oferi.' },
  { icon: TrendingUp, title: 'Trafic calificat', desc: 'Vizitatori cu intenție de cumpărare, nu trafic aleatoriu.' },
  { icon: Clock, title: 'Rezultate pe termen lung', desc: 'SEO construiește activ, nu cheltuială recurentă.' },
  { icon: Award, title: 'Credibilitate', desc: 'Pozițiile organice inspiră mai multă încredere decât reclamele.' },
]

const process = [
  { step: '01', title: 'Audit & Analiză', desc: 'Analizăm site-ul, competiția și oportunitățile. Identificăm problemele tehnice și zonele de îmbunătățire.' },
  { step: '02', title: 'Strategie SEO', desc: 'Creăm o strategie personalizată bazată pe obiectivele tale, cuvintele cheie relevante și bugetul disponibil.' },
  { step: '03', title: 'Optimizare Tehnică', desc: 'Rezolvăm problemele tehnice: viteză, indexare, structură, erori și toate aspectele care afectează ranking-ul.' },
  { step: '04', title: 'Optimizare Conținut', desc: 'Optimizăm paginile existente și creăm conținut nou pentru cuvintele cheie țintă.' },
  { step: '05', title: 'Link Building', desc: 'Construim autoritate prin backlink-uri de calitate din surse relevante și de încredere.' },
  { step: '06', title: 'Monitorizare & Raportare', desc: 'Urmărim pozițiile, traficul și conversiile. Ajustăm strategia continuu pentru rezultate optime.' },
]

const faqs = [
  {
    q: 'Cât durează până văd rezultate din SEO?',
    a: 'SEO este o investiție pe termen lung. Primele îmbunătățiri apar de obicei în 2-3 luni, dar rezultate semnificative se văd în 4-6 luni. Variază în funcție de competiție, starea actuală a site-ului și resursele alocate.'
  },
  {
    q: 'Garantați poziția 1 pe Google?',
    a: 'Nu, și nimeni nu poate garanta asta în mod etic. Google controlează algoritmul și nicio agenție nu îl poate manipula garantat. Ce garantăm sunt practici corecte, transparență și îmbunătățiri măsurabile în timp.'
  },
  {
    q: 'Care este diferența între SEO și Google Ads?',
    a: 'SEO aduce trafic organic gratuit, dar necesită timp. Google Ads aduce rezultate imediate, dar plătești pentru fiecare click. Ideal este să le combini: Ads pentru rezultate rapide, SEO pentru creștere sustenabilă.'
  },
  {
    q: 'Funcționează SEO pentru orice tip de afacere?',
    a: 'Da, dacă oamenii caută pe Google ce oferi, SEO funcționează. Este deosebit de eficient pentru servicii locale, e-commerce, B2B și orice afacere cu ciclu de decizie în care clienții cercetează online.'
  },
  {
    q: 'Ce primesc în raportul lunar?',
    a: 'Poziții pentru cuvintele cheie monitorizate, evoluția traficului organic, conversii atribuite SEO, acțiunile efectuate în luna respectivă, probleme identificate și recomandări pentru luna următoare.'
  },
  {
    q: 'Pot face SEO singur sau am nevoie de o agenție?',
    a: 'Poți face SEO de bază singur (optimizare on-page, conținut), dar SEO tehnic avansat, link building și strategie competitivă necesită expertiză și instrumente profesionale. O agenție accelerează rezultatele și evită greșelile costisitoare.'
  },
]

const stats = [
  { value: '68%', label: 'din experiențele online încep cu o căutare' },
  { value: '75%', label: 'nu trec niciodată de prima pagină Google' },
  { value: '14.6%', label: 'rată de conversie medie pentru lead-uri SEO' },
  { value: '5.7x', label: 'ROI mai mare decât publicitatea plătită' },
]

export default function SEOPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <Navbar />
      <main>
        {/* Hero */}
        <section className="relative pt-28 pb-14 bg-primary overflow-hidden">
          <div 
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3Cpath d='M6 5V0H5v5H0v1h5v94h1V6h94V5H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
            aria-hidden="true"
          />
          <div className="absolute top-1/3 left-0 w-[500px] h-[500px] rounded-full opacity-10 blur-3xl pointer-events-none" style={{ background: 'oklch(0.55 0.22 250)' }} />
          
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
              <div className="inline-flex items-center gap-2 bg-white/10 text-white/80 text-xs font-medium px-3 py-1.5 rounded-full mb-6 border border-white/10">
                <Search size={14} />
                Vizibilitate organică
              </div>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6 text-balance">
                Optimizare SEO
                <span className="block text-2xl sm:text-3xl lg:text-4xl mt-2" style={{ color: 'oklch(0.72 0.14 70)' }}>
                  Fii găsit de clienți pe Google
                </span>
              </h1>
              <p className="text-white/70 text-lg sm:text-xl leading-relaxed mb-8 max-w-2xl">
                Servicii SEO complete: audit tehnic, optimizare on-page, conținut și link building. 
                Creștem vizibilitatea ta pe Google cu rezultate măsurabile și raportare transparentă.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link
                  href="/contact"
                  className="inline-flex items-center justify-center gap-2 bg-white text-primary px-7 py-3.5 rounded-xl font-semibold text-sm hover:bg-white/90 transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5"
                >
                  Solicită audit SEO gratuit
                  <ArrowRight size={16} />
                </Link>
                <Link
                  href="/portofoliu"
                  className="inline-flex items-center justify-center gap-2 border border-white/20 text-white px-7 py-3.5 rounded-xl font-semibold text-sm hover:bg-white/10 transition-all duration-200"
                >
                  Vezi rezultate
                </Link>
              </div>
              </div>
              <PageHeroVisual page="optimizare-seo" />
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 bg-accent-brand">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="font-display text-4xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-white/70 text-sm">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit) => {
                const Icon = benefit.icon
                return (
                  <div key={benefit.title} className="bg-secondary/40 rounded-xl p-6">
                    <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <Icon size={20} className="text-primary" />
                    </div>
                    <h3 className="font-display font-bold text-foreground mb-2">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{benefit.desc}</p>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Services */}
        <section className="py-14 bg-secondary/40" id="servicii">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <p className="text-accent-brand font-semibold text-sm uppercase tracking-widest mb-3">
                Servicii SEO complete
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-primary leading-tight mb-4 text-balance">
                Tot ce ai nevoie pentru a domina căutările
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                O abordare completă care acoperă toate aspectele SEO: tehnic, conținut și autoritate.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => {
                const Icon = service.icon
                return (
                  <div key={service.title} className="bg-white rounded-2xl p-6 border border-border hover:shadow-md transition-shadow">
                    <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <Icon size={20} className="text-primary" />
                    </div>
                    <h3 className="font-display font-bold text-foreground mb-2">{service.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{service.desc}</p>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-14 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <p className="text-accent-brand font-semibold text-sm uppercase tracking-widest mb-3">
                Procesul nostru SEO
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-primary leading-tight mb-4 text-balance">
                Cum creștem vizibilitatea ta pe Google
              </h2>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {process.map((item) => (
                <div key={item.step} className="bg-secondary/40 rounded-2xl p-6 relative overflow-hidden group hover:bg-secondary/60 transition-colors">
                  <span className="absolute -top-4 -right-2 font-display text-8xl font-bold text-primary/5 group-hover:text-primary/10 transition-colors">
                    {item.step}
                  </span>
                  <div className="relative z-10">
                    <span className="inline-block text-xs font-bold text-accent-brand bg-accent-brand/10 px-2.5 py-1 rounded-full mb-3">
                      Pasul {item.step}
                    </span>
                    <h3 className="font-display font-bold text-foreground mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SEO Content */}
        <section className="py-14 bg-secondary/40">
          <div className="max-w-4xl mx-auto px-6 lg:px-8">
            <article className="prose prose-lg max-w-none">
              <h2 className="font-display text-3xl font-bold text-primary mb-6">
                De ce este SEO esențial pentru afacerea ta în 2026?
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                <strong>Optimizarea pentru motoarele de căutare (SEO)</strong> este procesul prin care îți crești vizibilitatea 
                în rezultatele organice ale Google. Când potențialii clienți caută produse sau servicii pe care le oferi, 
                vrei să fii în primele rezultate — nu pe pagina 2 sau 3, unde aproape nimeni nu ajunge.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Conform statisticilor, <strong>68% din experiențele online încep cu o căutare</strong>, iar 75% din utilizatori 
                nu trec niciodată de prima pagină de rezultate. Dacă nu ești acolo, practic nu exiști pentru acești potențiali clienți.
              </p>
              
              <h3 className="font-display text-xl font-bold text-primary mt-10 mb-4">
                SEO vs. Publicitate plătită — care este diferența?
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Publicitatea plătită (Google Ads) aduce rezultate imediate, dar costul crește constant și dispare în momentul 
                în care oprești bugetul. <strong>SEO-ul construiește un activ</strong> — odată ce ajungi în poziții bune, 
                traficul continuă să vină fără costuri per click. Investiția în SEO are un ROI de până la 5.7x mai mare 
                decât publicitatea plătită pe termen lung.
              </p>

              <h3 className="font-display text-xl font-bold text-primary mt-10 mb-4">
                Servicii SEO profesionale în România
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                La FXF Web Solution, oferim <strong>servicii complete de optimizare SEO</strong> pentru afaceri din Romania. 
                De la audit tehnic și optimizare on-page, până la creație de conținut și link building, acoperim toate aspectele 
                necesare pentru a-ți crește vizibilitatea organică. Lucrăm transparent, cu rapoarte lunare detaliate și 
                rezultate măsurabile.
              </p>
            </article>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-14 bg-white">
          <div className="max-w-3xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-12">
              <p className="text-accent-brand font-semibold text-sm uppercase tracking-widest mb-3">
                Întrebări frecvente
              </p>
              <h2 className="font-display text-3xl font-bold text-primary text-balance">
                Ce trebuie să știi despre SEO
              </h2>
            </div>

            <div className="space-y-4">
              {faqs.map((faq, i) => (
                <details key={i} className="bg-secondary/40 rounded-xl border border-border group">
                  <summary className="flex items-center justify-between p-5 cursor-pointer font-medium text-foreground hover:text-primary transition-colors">
                    {faq.q}
                    <span className="ml-4 shrink-0 w-5 h-5 rounded-full bg-white flex items-center justify-center group-open:bg-primary group-open:text-white transition-colors">
                      <svg className="w-3 h-3 transition-transform group-open:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </span>
                  </summary>
                  <div className="px-5 pb-5 text-muted-foreground text-sm leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-14 bg-primary">
          <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4 text-balance">
              Gata să fii găsit pe Google?
            </h2>
            <p className="text-white/60 text-lg mb-8 max-w-xl mx-auto">
              Solicită un audit SEO gratuit și descoperă oportunitățile de creștere pentru afacerea ta.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-xl font-semibold hover:bg-white/90 transition-all hover:-translate-y-0.5"
            >
              Solicită audit SEO gratuit <ArrowRight size={16} />
            </Link>
          </div>
        </section>

        {/* Related Services */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-xl font-bold text-center text-foreground mb-8">
              Servicii complementare
            </h2>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/servicii/google-ads" className="flex items-center gap-2 bg-secondary/60 px-5 py-3 rounded-xl text-sm font-medium text-foreground hover:bg-secondary transition-colors">
                <BarChart2 size={16} className="text-primary" />
                Google Ads
              </Link>
              <Link href="/servicii/web-design" className="flex items-center gap-2 bg-secondary/60 px-5 py-3 rounded-xl text-sm font-medium text-foreground hover:bg-secondary transition-colors">
                <Globe size={16} className="text-primary" />
                Web Design SEO-Friendly
              </Link>
              <Link href="/servicii/mentenanta-web" className="flex items-center gap-2 bg-secondary/60 px-5 py-3 rounded-xl text-sm font-medium text-foreground hover:bg-secondary transition-colors">
                <Gauge size={16} className="text-primary" />
                Mentenanță & Optimizare
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
